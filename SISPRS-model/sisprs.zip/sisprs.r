library(sn)

pde.delta <- function(maxAge, gridAge, endTime, timeOut, birth, death, beta1, beta2, gamma1, gamma2, zeta1, zeta2, xi1, xi2, xi12, kappa,
                      inits, c_rates, epsilon, prefinits, a.pref, p.pref, v.pref, position, vac.rate, vac.take, vac.degree, vac.start) {
  
  ageSteps <- (1+(maxAge-minAge)/gridAge)
  outPoints <- 1 + endTime - timeOut
  timeAgeSubgrps <- outPoints * ageSteps * length(inits)
  timeSeries <- .C("pde_solver", as.double(gridAge), as.integer(ageSteps), as.integer(endTime), as.integer(timeOut), time = double(outPoints),
   as.integer(length(inits)), as.double(inits), as.double(c_rates), as.double(epsilon), as.double(prefinits),
   as.double(birth), as.double(death), as.double(c(beta1, beta2, gamma1, gamma2, zeta1, zeta2, xi1, xi2, xi12, kappa, vac.start)),
   as.double(a.pref), a.foi10 = double(timeAgeSubgrps),
   as.double(p.pref), p.foi02 = double(timeAgeSubgrps),
   as.double(v.pref),  as.double(position), v.foi10 = double(timeAgeSubgrps), v.foi02 = double(timeAgeSubgrps), v.foi12 = double(timeAgeSubgrps),
   a.X = double(timeAgeSubgrps), a.Y1 = double(timeAgeSubgrps), a.P1 = double(timeAgeSubgrps), a.R = double(timeAgeSubgrps),
   p.X = double(timeAgeSubgrps), p.Y2 = double(timeAgeSubgrps), p.P2 = double(timeAgeSubgrps), p.R = double(timeAgeSubgrps),
   v.X = double(timeAgeSubgrps), v.Y1 = double(timeAgeSubgrps), v.Y2 = double(timeAgeSubgrps), v.Y12 = double(timeAgeSubgrps), 
   v.P1 = double(timeAgeSubgrps), v.P2 = double(timeAgeSubgrps), v.Z1 = double(timeAgeSubgrps), v.Z2 = double(timeAgeSubgrps),
   v.Z12 = double(timeAgeSubgrps), v.R = double(timeAgeSubgrps),
   as.double(vac.rate), as.double(vac.take), as.double(vac.degree),
   a.Xv = double(timeAgeSubgrps), a.Y1v = double(timeAgeSubgrps), a.P1v = double(timeAgeSubgrps), a.Rv = double(timeAgeSubgrps),
   p.Xv = double(timeAgeSubgrps), p.Y2v = double(timeAgeSubgrps), p.P2v = double(timeAgeSubgrps), p.Rv = double(timeAgeSubgrps),
   v.Xv = double(timeAgeSubgrps), v.Y1v = double(timeAgeSubgrps), v.Y2v = double(timeAgeSubgrps), v.Y12v = double(timeAgeSubgrps), 
   v.P1v = double(timeAgeSubgrps), v.P2v = double(timeAgeSubgrps), v.Z1v = double(timeAgeSubgrps), v.Z2v = double(timeAgeSubgrps),
   v.Z12v = double(timeAgeSubgrps), v.Rv = double(timeAgeSubgrps),
   a.N = double(timeAgeSubgrps), p.N = double(timeAgeSubgrps), v.N = double(timeAgeSubgrps), N = double(timeAgeSubgrps))

  time <- timeSeries[["time"]]
  time_age <- c(outPoints, ageSteps)
  time_age_subgrps <- c(outPoints, ageSteps, length(inits))
  
  a.foi10 <- timeSeries[["a.foi10"]]; dim(a.foi10) <- time_age_subgrps
  
  p.foi02 <- timeSeries[["p.foi02"]]; dim(p.foi02) <- time_age_subgrps
  
  v.foi10 <- timeSeries[["v.foi10"]]; dim(v.foi10) <- time_age_subgrps
  v.foi02 <- timeSeries[["v.foi02"]]; dim(v.foi02) <- time_age_subgrps
  v.foi12 <- timeSeries[["v.foi12"]]; dim(v.foi12) <- time_age_subgrps

  a.X <- timeSeries[["a.X"]]; dim(a.X) <- time_age_subgrps
  a.Y1 <- timeSeries[["a.Y1"]]; dim(a.Y1) <- time_age_subgrps
  a.P1 <- timeSeries[["a.P1"]]; dim(a.P1) <- time_age_subgrps
  a.R <- timeSeries[["a.R"]]; dim(a.R) <- time_age_subgrps
  a.Xv <- timeSeries[["a.Xv"]]; dim(a.Xv) <- time_age_subgrps
  a.Y1v <- timeSeries[["a.Y1v"]]; dim(a.Y1v) <- time_age_subgrps
  a.P1v <- timeSeries[["a.P1v"]]; dim(a.P1v) <- time_age_subgrps
  a.Rv <- timeSeries[["a.Rv"]]; dim(a.Rv) <- time_age_subgrps
  
  p.X <- timeSeries[["p.X"]]; dim(p.X) <- time_age_subgrps
  p.Y2 <- timeSeries[["p.Y2"]]; dim(p.Y2) <- time_age_subgrps
  p.P2 <- timeSeries[["p.P2"]]; dim(p.P2) <- time_age_subgrps
  p.R <- timeSeries[["p.R"]]; dim(p.R) <- time_age_subgrps
  p.Xv <- timeSeries[["p.Xv"]]; dim(p.Xv) <- time_age_subgrps
  p.Y2v <- timeSeries[["p.Y2v"]]; dim(p.Y2v) <- time_age_subgrps
  p.P2v <- timeSeries[["p.P2v"]]; dim(p.P2v) <- time_age_subgrps
  p.Rv <- timeSeries[["p.Rv"]]; dim(p.Rv) <- time_age_subgrps
  
  v.X <- timeSeries[["v.X"]]; dim(v.X) <- time_age_subgrps
  v.Y1 <- timeSeries[["v.Y1"]]; dim(v.Y1) <- time_age_subgrps
  v.Y2 <- timeSeries[["v.Y2"]]; dim(v.Y2) <- time_age_subgrps
  v.Y12 <- timeSeries[["v.Y12"]]; dim(v.Y12) <- time_age_subgrps
  v.P1 <- timeSeries[["v.P1"]]; dim(v.P1) <- time_age_subgrps
  v.P2 <- timeSeries[["v.P2"]]; dim(v.P2) <- time_age_subgrps
  v.Z1 <- timeSeries[["v.Z1"]]; dim(v.Z1) <- time_age_subgrps
  v.Z2 <- timeSeries[["v.Z2"]]; dim(v.Z2) <- time_age_subgrps
  v.Z12 <- timeSeries[["v.Z12"]]; dim(v.Z12) <- time_age_subgrps
  v.R <- timeSeries[["v.R"]]; dim(v.R) <- time_age_subgrps
  v.Xv <- timeSeries[["v.Xv"]]; dim(v.Xv) <- time_age_subgrps
  v.Y1v <- timeSeries[["v.Y1v"]]; dim(v.Y1v) <- time_age_subgrps
  v.Y2v <- timeSeries[["v.Y2v"]]; dim(v.Y2v) <- time_age_subgrps
  v.Y12v <- timeSeries[["v.Y12v"]]; dim(v.Y12v) <- time_age_subgrps
  v.P1v <- timeSeries[["v.P1v"]]; dim(v.P1v) <- time_age_subgrps
  v.P2v <- timeSeries[["v.P2v"]]; dim(v.P2v) <- time_age_subgrps
  v.Z1v <- timeSeries[["v.Z1v"]]; dim(v.Z1v) <- time_age_subgrps
  v.Z2v <- timeSeries[["v.Z2v"]]; dim(v.Z2v) <- time_age_subgrps
  v.Z12v <- timeSeries[["v.Z12v"]]; dim(v.Z12v) <- time_age_subgrps
  v.Rv <- timeSeries[["v.Rv"]]; dim(v.Rv) <- time_age_subgrps
  
  a.N <- timeSeries[["a.N"]]; dim(a.N) <- time_age_subgrps
  p.N <- timeSeries[["p.N"]]; dim(p.N) <- time_age_subgrps
  v.N <- timeSeries[["v.N"]]; dim(v.N) <- time_age_subgrps
  N <- timeSeries[["N"]]; dim(N) <- time_age_subgrps
  
  SISPRS3 <- list(time, a.foi10, p.foi02, v.foi10, v.foi02, v.foi12,
   a.X, a.Y1, a.P1, a.R, a.Xv, a.Y1v, a.P1v, a.Rv,
   p.X, p.Y2, p.P2, p.R, p.Xv, p.Y2v, p.P2v, p.Rv,
   v.X, v.Y1, v.Y2, v.Y12, v.P1, v.P2, v.Z1, v.Z2, v.Z12, v.R,
   v.Xv, v.Y1v, v.Y2v, v.Y12v, v.P1v, v.P2v, v.Z1v, v.Z2v, v.Z12v, v.Rv,
   a.N, p.N, v.N, N)
  names(SISPRS3) <- c("time", "a.foi10", "p.foi02", "v.foi10", "v.foi02", "v.foi12",
   "a.X", "a.Y1", "a.P1", "a.R", "a.Xv", "a.Y1v", "a.P1v", "a.Rv",
   "p.X", "p.Y2", "p.P2", "p.R", "p.Xv", "p.Y2v", "p.P2v", "p.Rv",
   "v.X", "v.Y1", "v.Y2", "v.Y12", "v.P1", "v.P2", "v.Z1", "v.Z2", "v.Z12", "v.R",
   "v.Xv", "v.Y1v", "v.Y2v", "v.Y12v", "v.P1v", "v.P2v", "v.Z1v", "v.Z2v", "v.Z12v", "v.Rv",
   "a.N", "p.N", "v.N", "N")
  return(SISPRS3)

}

### dll allowing for waning systemic immunity
dyn.load("sisprs")

minAge <- 9
maxAge <- 80
gridAge <- 1/4 # try with different value; first order accuracy!?
axisAge <- (minAge/gridAge):(maxAge/gridAge)*gridAge

birth.sln <- dsn(log(axisAge), xi=2.846, omega=0.298, alpha=1.421)
birth <- birth.sln / axisAge
sum(birth * gridAge) # check that the pdf sums to unity!
plot(birth ~ axisAge, type="l", xlab="Age")

death.pdf <- dweibull(c(axisAge-25), shape=3, scale=30)
lines(death.pdf ~ axisAge, col="red")
pweibull(maxAge-25, shape=3, scale=30) # pdf need not sum to unity...
death <- (3/30) * (pmax(axisAge-25,0)/30)^(3-1) # use hazard function!

# sexual activity
K <- 2
inits <- c(9,1)/10
sum(inits) == 1 # check
c_rate <- c(3.5264,61.0624) # use 2_princes.r
c_rates <- array(NA, dim=c(length(axisAge), K))
plot(c_rates[,1] ~ axisAge, xlab="Age", ylim=c(0, 1.5 * max(c_rate)))
for (k in 1:K) {
#  c_rates[,k] <- rep(c_rate[k], length(axisAge))
  c_rates[,k] <-  4 * c_rate[k] * (axisAge-gridAge)/maxAge * (1 - (axisAge-gridAge)/maxAge)
}
for (k in 1:K) lines(c_rates[,k] ~ axisAge, col=k)

# contact network
pref.q <- 0.13 # between 0 and 0.5
pref.inits <- c(pref.q, pref.q, 1-2*pref.q)
pref.pi <- 0.5
pref.pi >= 2 - 1/(2*pref.q) # check restriction
pref.a <- c(0, pref.pi, 1-pref.pi)
pref.p <- c(pref.pi, 0, 1-pref.pi)
pref.v <- c(pref.q*(1-pref.pi)/(1-2*pref.q), pref.q*(1-pref.pi)/(1-2*pref.q), 1-2*pref.q*(1-pref.pi)/(1-2*pref.q))
# conditional preference
p <- 0.202
rho <- (p-pref.v[1])/pref.v[3]
rho > 0 & rho < 0.5 # check restriction
sexpos <- c(rho, rho, 1-2*rho)
sexpos
# subgroup assortativity - see Xiridou Infect Dis 2013
epsilon <- 0.67

# use estimates from survival analysis under base-case censoring assumption
gamma1 <- 3.401
zeta1 <- 5.478
xi1 <- 0.425
gamma2 <- 1.300
zeta2 <- 3.467
xi2 <- 0.329
xi12 <- min(xi1,xi2)

# specify site-specific transmission probabilities and loss of immunity
beta1 <- 0.5
beta2 <- 0.25
kappa <- 0.1

# vaccination
vac.start <- 100
vac.a0 <- 15
vac.a1 <- 27 # choose 27|40|80
uptake <- dgamma((axisAge-vac.a0)/5, shape=2, scale=2)
vac.rate <- 0.02 * uptake/max(uptake)
vac.rate[axisAge>vac.a1] <- 0
vac.take <- rep(0.85,10) # all-or-nothing irrespective infection status
vac.degree <- 0.999 # assume (almost) complete hazard reduction

endTime <- 180
timeOut <- 90

output <- pde.delta(maxAge, gridAge, endTime, timeOut, birth, death, beta1, beta2, gamma1, gamma2, zeta1, zeta2, xi1, xi2, xi12, kappa,
                    inits, c_rates, epsilon, pref.inits, pref.a, pref.p, pref.v, sexpos, vac.rate, vac.take, vac.degree, vac.start)

plot(rowSums(output[["N"]])~output[["time"]],type="l",ylim=c(0,1))
lines(rowSums(output[["a.N"]])~output[["time"]],col="red")
lines(rowSums(output[["p.N"]])~output[["time"]],col="blue")
lines(rowSums(output[["v.N"]])~output[["time"]],col="purple")

x11()
mod16_x10 <- apply(output[["a.Y1"]]+output[["a.P1"]]+output[["v.Y1"]]+output[["v.P1"]]+output[["a.Y1v"]]+output[["a.P1v"]]+output[["v.Y1v"]]+output[["v.P1v"]],1,sum)/apply(output[["N"]],1,sum)
mod16_x01 <- apply(output[["p.Y2"]]+output[["p.P2"]]+output[["v.Y2"]]+output[["v.P2"]]+output[["p.Y2v"]]+output[["p.P2v"]]+output[["v.Y2v"]]+output[["v.P2v"]],1,sum)/apply(output[["N"]],1,sum)
mod16_x11 <- apply(output[["v.Y12"]]+output[["v.Z1"]]+output[["v.Z2"]]+output[["v.Z12"]]+output[["v.Y12v"]]+output[["v.Z1v"]]+output[["v.Z2v"]]+output[["v.Z12v"]],1,sum)/apply(output[["N"]],1,sum)
vacc <- apply(output[["a.Xv"]]+output[["a.Y1v"]]+output[["a.P1v"]]+output[["a.Rv"]]+output[["p.Xv"]]+output[["p.Y2v"]]+output[["p.P2v"]]+output[["p.Rv"]]+output[["v.Xv"]]+output[["v.Y1v"]]+output[["v.Y2v"]]+output[["v.Y12v"]]+output[["v.P1v"]]+output[["v.P2v"]]+output[["v.Z1v"]]+output[["v.Z2v"]]+output[["v.Z12v"]]+output[["v.Rv"]],1,sum)/apply(output[["N"]],1,sum)

x11()
plot(c(mod16_x01+mod16_x11) ~ output[["time"]], type="l", lwd=2)
lines(c(mod16_x10+mod16_x11) ~ output[["time"]])

TheLastTime <- endTime - timeOut + 1

x11()
plot(rowSums(output[["N"]][TheLastTime,,])~axisAge,type="l")
lines(rowSums(output[["a.N"]][TheLastTime,,])~axisAge,col="red")
lines(rowSums(output[["p.N"]][TheLastTime,,])~axisAge,col="blue")
lines(rowSums(output[["v.N"]][TheLastTime,,])~axisAge,col="purple")

x11()
plot(rowSums(output[["v.X"]][TheLastTime,,])/rowSums(output[["v.N"]][TheLastTime,,])~axisAge,type="l",ylim=c(0,1))
lines(rowSums(output[["v.Xv"]][TheLastTime,,])/rowSums(output[["v.N"]][TheLastTime,,])~axisAge,lty=2)
lines(rowSums(output[["v.Y1"]][TheLastTime,,])/rowSums(output[["v.N"]][TheLastTime,,])~axisAge,col="red")
lines(rowSums(output[["v.Y2"]][TheLastTime,,])/rowSums(output[["v.N"]][TheLastTime,,])~axisAge,col="blue")
lines(rowSums(output[["v.Y12"]][TheLastTime,,])/rowSums(output[["v.N"]][TheLastTime,,])~axisAge,col="purple")
lines(rowSums(output[["v.P1"]][TheLastTime,,])/rowSums(output[["v.N"]][TheLastTime,,])~axisAge,col="red",lty=2)
lines(rowSums(output[["v.P2"]][TheLastTime,,])/rowSums(output[["v.N"]][TheLastTime,,])~axisAge,col="blue",lty=2)
lines(rowSums(output[["v.Z1"]][TheLastTime,,])/rowSums(output[["v.N"]][TheLastTime,,])~axisAge,col="red",lwd=2)
lines(rowSums(output[["v.Z2"]][TheLastTime,,])/rowSums(output[["v.N"]][TheLastTime,,])~axisAge,col="blue",lwd=2)
lines(rowSums(output[["v.Z12"]][TheLastTime,,])/rowSums(output[["v.N"]][TheLastTime,,])~axisAge,col="purple",lwd=2)
lines(rowSums(output[["v.R"]][TheLastTime,,])/rowSums(output[["v.N"]][TheLastTime,,])~axisAge,col="magenta")
